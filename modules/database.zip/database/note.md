User - payment Service: 



DataBase Table :
confirmation



customers

customer_transactions

customer_wallets_previous_day


-----------------------------------------
partners and stores and dashboard 




DataBase Table :
admins
electronic_payment
roles

permisions

role_permission


daily_statistics

statistics_previous_day


partners

stores

address

store_wallets

store_transactions

store_categories

tags

store_tags

store_ratings_previous_day

working_hours

products

products_sold

trends

coupons

document_images

system_settings

-------------------------------------------------
Order Service : 



DataBase Table :
    current_orders

    past_orders

    order_status

    order_financial_logs

    ratings
    
----------------------------------------------------
delivery service : 



DataBase Table :

drivers
driver_wallets_previous_day
driver_points
trust_points_log
driver_transactions

delivery_document_images
----------------------------------------------------------


