/*
generateAddress //done
generateStoreCategoriesArray //done
generatetag //done
generateCustomers  //done
generateCustomerWallets//done
generateDrivers//done
generateDriverPoints//done
generateDriverWalletsPreviousDay//done
generatePartner//done
generateStore//done
generateStoreWallet//done
generateStoreTag//done
generateTrends//done
generateWorkingHours//done
generateProducts//done
generateCoupoun//done
generateElectronicPayment//done
generateCurrentOrder//done
generateOrderStatus//done
generateRating//done
generatepastOrder//done
generateTrustPoint//done
generateorderFinancialLogs//done
generateDriverTransactions//done
generateStoreRatings//done
generateCustomerTransaction//done
generateStoreTransactions//done
generateDocumentImages//done
generateSoldProduct//done
generateDailyStatistics//done
generateStatisticsPreviousDayArray//done
generateSystemSettings//done

*/